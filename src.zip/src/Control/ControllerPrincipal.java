package Control;

import Vista.Principal;
import java.awt.CardLayout;
import javax.swing.JButton;

public class ControllerPrincipal {

    private Principal vista;

    public ControllerPrincipal(Principal vista) {
        this.vista = vista;

        conectar(vista.getBtnProducts(), "products");
        conectar(vista.getBtnClients(), "clients");
        conectar(vista.getBtnInventario(), "inventario");
        conectar(vista.getBtnPedidos(), "order");
        conectar(vista.getBtnMesas(), "mesas");
       // conectar(vista.getBtnFacturacion(), "facturacion");
        conectar(vista.getBtnStart(), "vacio");
    }

    
    private void conectar(JButton boton, String panel) {
        boton.addActionListener(e -> activarBoton(boton, panel));
    }

    private void activarBoton(JButton activo, String panel) {

        // 1️⃣ Apagar TODOS
        apagar(vista.getBtnProducts());
        apagar(vista.getBtnClients());
        apagar(vista.getBtnInventario());
        apagar(vista.getBtnPedidos());
        apagar(vista.getBtnMesas());
      //  apagar(vista.getBtnFacturacion());
        apagar(vista.getBtnStart());

        // 2️⃣ Encender el activo
        activo.setOpaque(true);
        activo.repaint();

        // 3️⃣ Cambiar panel
        CardLayout cl = (CardLayout) vista.getPanelContenido().getLayout();
        cl.show(vista.getPanelContenido(), panel);
    }

    private void apagar(JButton b) {
        b.setOpaque(false);
        b.repaint();
    }
}
