/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.JComponent;
import javax.swing.JOptionPane;

/**
 *
 * @author Jefferson granados
 */
public class Mensajes {
    
    public void message(String msg){
        JOptionPane.showMessageDialog(null, msg);
    } 
    
    
    
}
